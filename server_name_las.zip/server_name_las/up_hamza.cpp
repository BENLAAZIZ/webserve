int Response::open_file(int *flag, std::string fullPath, int *code)
{
	// permition denied
	if (access(fullPath.c_str(), R_OK) == -1)
	{
		std::cerr << "Permission denied: " << fullPath << std::endl;
		*code = 403;
		*flag = 1;
		return 1;
	}
	file.open(fullPath, std::ios::binary);
	if (!file) {
		std::cerr << "Failed to open file: " << fullPath << std::endl;
		*code = 500;
		*flag = 1;
		return 1;
	}
	// std::cout << "File opened successfully: " << fullPath << std::endl;
	return 0;
}



====================================



bool Client::handleDeleteResponse()
{
	std::string targetPath = _request.getpath();

	if (_request.getStatusCode() >= 400) {
		std::cout << "Error: " << _request.getStatusCode() << std::endl;
		return true;
	}	
	if (access(targetPath.c_str(), W_OK) != 0) {
		_request.set_status_code(403);
		return true;
	}

	if (remove(targetPath.c_str()) != 0) {
		_request.set_status_code(500);  // Internal Server Error
		return true;
	}
	_request.setMethod("GET");
	std::string fullPath;
	fullPath = join_paths(_request.my_root, "docs/delete/suc.html");
	_request.setPath(fullPath);

	_request.set_status_code(204);
	return false;
}

=========================================


std::vector<Location*> get_matching_locations(const std::string& url, std::vector<Location>& locations) {
    std::vector<Location*> matches;

    for (std::vector<Location>::iterator it = locations.begin(); it != locations.end(); ++it) {
        if (url.find(it->path) == 0) { // location path is a prefix of URL
            matches.push_back(&(*it));
        }
    }
    return matches;
}
Location* get_best_location_match(const std::string& url, std::vector<Location>& locations) {
    std::vector<Location*> matches = get_matching_locations(url, locations);

    Location* best = NULL;
    size_t max_len = 0;

    for (size_t i = 0; i < matches.size(); ++i) {
        if (matches[i]->path.length() > max_len) {
            max_len = matches[i]->path.length();
            best = matches[i];
        }
    }
    return best;
}

int  Client::resolve_request_path(Server_holder & serv_hldr) {

	Location* loc = get_best_location_match(_request.getpath(), serv_hldr.locations);
	std::cout << "Matching locations found" << std::endl;
	std::cout << "location path: " << loc->path << std::endl;

	std::string root = loc ? loc->root : serv_hldr.root;
	std::string location_path = loc ? loc->path : "/";
	std::string getpath = _request.getpath();
	_request.set_fake_path(getpath);

	if (loc && loc->root.empty() && serv_hldr.root.empty()) 
		return (_request.set_status_code(500), 500);
	if (loc == NULL) {
		full_path = join_paths(_request.my_root, join_paths(serv_hldr.root, getpath));
		if (is_directory(full_path))
			full_path = join_paths(full_path, "index.html");
		std::cout << "Location not found - full_path = " << full_path << std::endl;
		if (file_exists(full_path)) 
			return (_request.setPath(full_path), full_path.clear(), _request.set_status_code(200), 200);
		else
			return (_request.set_status_code(404), 404);
	}

	std::string relative_path = getpath;
	if (loc && getpath.find(location_path) == 0)
		relative_path = getpath.substr(location_path.length());

	if (!relative_path.empty() && relative_path[0] == '/')
		relative_path = relative_path.substr(1);
	//  DUPLICATE CHECK
	std::string lastRootSegment = root.substr(root.find_last_of('/') + 1);
	if (relative_path == lastRootSegment)
		relative_path.clear();
	if (relative_path.find(lastRootSegment + "/") == 0) {
		relative_path = relative_path.substr(lastRootSegment.length() + 1);
	}
	// Now use the correct root
	if (loc && root.empty())
	{
		root = serv_hldr.root;
		full_path = join_paths(_request.my_root, join_paths(root, getpath));
	}
	else
		full_path = join_paths(_request.my_root, join_paths(root, relative_path));
	// redirect path
	if (loc && loc->redirect_code != 0) 
	{
		if (loc->redirect_url.empty()) 
			return (_request.set_status_code(400), 400);
		return (_request.setPath(loc->redirect_url), _request.set_status_code(loc->redirect_code), loc->redirect_code);
	}
	// check allowed methods
	if (loc && loc->allowed_methods.size() > 0)
	{
		std::string method = _request.getMethod();
		if (std::find(loc->allowed_methods.begin(), loc->allowed_methods.end(), method) == loc->allowed_methods.end())
			return (_request.set_status_code(405), 405);
	}
	else
		return (_request.set_status_code(405), 405);
	if (_request.isCGI)
		return (_request.setPath(full_path), 200);
	// Check if full_path is a directory or a file
	if (is_directory(full_path)) 
	{
		if (_request.getMethod() == "DELETE")
			return (_request.set_status_code(403), 403);
		if (loc && !loc->index.empty()) {
			std::string index_path = join_paths(full_path, loc->index[0]);
			if (file_exists(index_path))
				return (_request.setPath(index_path), full_path.clear(), _request.set_status_code(200), 200);
			else
				return (_request.set_status_code(404), 404);
		}
		else if (loc && loc->autoindex)
			return (_request.set_status_code(200), _request.setPath(full_path), full_path.clear(), 200);
		return (_request.set_status_code(403), 403);
	}
	else if (file_exists(full_path))
	{
		return (_request.setPath(full_path), full_path.clear(), _request.set_status_code(200), 200);
	}
	return (_request.set_status_code(404), 404);
}
